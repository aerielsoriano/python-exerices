import turtle

def first():
  line = turtle.Turtle()

  line.left(60)
  line.backward(100)
  
  line.forward(100)
  line.right(120)
  line.forward(100)
  
  line.backward(50)
  line.right(120)
  line.forward(50)
  
  line.right(120)
  line.forward(50)
  line.right (60)
  
  line.penup()
  line.forward(150)
  line.pendown()
  
  line.backward(100)
  line.right(90)
  line.forward(40)
  
  line.left(90)
  line.forward(100)
  line.right(90)
  
  line.forward(45)
  line.left(90)
  line.backward(90)
  
first()